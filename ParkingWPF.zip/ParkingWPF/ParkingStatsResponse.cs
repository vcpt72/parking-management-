﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingWPF
{
    public class ParkingStatsResponse
    {
        public int EndedOccupationsLastMonth { get; set; }
    }
}
